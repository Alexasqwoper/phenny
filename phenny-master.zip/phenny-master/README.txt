Installation &c.

1) Run ./phenny - this creates a default config file
2) Edit ~/.phenny/default.py
3) Run ./phenny - this now runs phenny with your settings

Enjoy!

-- 
Sean B. Palmer, http://inamidst.com/sbp/
